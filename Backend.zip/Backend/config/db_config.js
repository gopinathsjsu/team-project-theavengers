module.exports = {
	DB_HOST: 'localhost',
	DB_PORT: 27017,
	DB_DATABASE: 'HotelBookingAvengers'
};