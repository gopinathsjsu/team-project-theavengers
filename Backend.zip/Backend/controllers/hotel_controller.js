const Hotel = require("../models/hotel_model");
const Booking=require("../models/booking_model");


//Searching hotel base on city name
exports.searchHotels =  (req,res) => {
     Hotel.find({
        city:req.params.city
    })
    .then((hotels) => {
        if(hotels.length==0)
            return res.status(200).send({results:"Hotels not found"});
        res.status(200).send({results:hotels});
        
    })
    .catch(err => {
        console.log(err);
        res.status(500).send("Error in fetching")
    });
};
// //checking room availablity
// exports.roomsavailability=(req,res)=>{
//     Booking.find({
//         hotelId:req.params.hotelId,
//         checkInDate:req.checkInDate,
//         checkOutDate:req.checkOutDate
//     })
// }

